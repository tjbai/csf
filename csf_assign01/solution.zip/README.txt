Halle Cho and TJ Bai pair programmed for the majority of this assignment.

For debugging and writing tests, Halle Cho worked primarily on the 
tests related to create_from_hex() and format_as_hex() whereas
TJ Bai worked primarily on addition, subtraction, and multiplication.